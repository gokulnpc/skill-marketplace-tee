# Ari Portable Skill

Portable AI-agent skill package for a public-corpus research skill derived from papers associated with Professor [Ari Juels](https://www.arijuels.com/) and his collaborators. Prof. Juels is the Weill Family Foundation and Joan and Sanford I. Weill Professor at Cornell Tech, co-director of IC3, and a long-running contributor to applied cryptography and blockchain security.

This package is designed for Codex, Claude Code, OpenCode, Aider, and generic LLM harnesses that can load Markdown instructions.

This package is not endorsed by Prof. Juels, Cornell Tech, IC3, or any collaborator unless explicitly stated. It is a research-skill example built from public artifacts, not a biography, advisor profile, personality model, or claim about private views.

## Package Contents

```text
ari-portable-skill/
  README.md
  skill/
    SKILL.md
    work.md
    work_skill.md
    persona.md
    persona_skill.md
    manifest.json
    meta.json
    knowledge/
      papers/
      synthesis/
      notes/
  adapters/
    codex/
    claude-code/
    opencode/
    generic/
```

The canonical skill is `skill/SKILL.md`. The `knowledge/` directory contains paper cards, synthesis notes, evidence maps, and validation notes. No original PDFs are included.

`persona.md` and `persona_skill.md` are kept for adapter compatibility. In this package, they mean paper-visible writing and explanation constraints only. They are not personality models and do not make claims about private behavior, personal views, or mentoring style.

## What This Skill Does

Use this skill when you want an agent to reason with paper-visible research patterns drawn from a public corpus associated with Prof. Juels and his collaborators:

* Applied cryptography and systems security
* Blockchain security, smart contracts, oracles, MEV, DAO governance, and cryptoeconomic attacks
* Research ideation, paper framing, experiment design, rebuttal planning, and talk outlines
* Strong attention to assumption failures, adversarial models, economic incentives, baselines, and model boundaries

The skill is meant to capture research patterns visible in public papers: how assumptions are framed, how threat models are separated, how systems and primitives are connected, how baselines are chosen, how evaluation claims are bounded, and how limitations are stated.

This is not a biography or personality imitation package. It does not use private correspondence, unpublished drafts, personal communications, mentoring style, or claims about private beliefs.

## Codex Install

From the package root:

```bash
mkdir -p ~/.codex/skills/professor-ari-juels
cp adapters/codex/professor-ari-juels/SKILL.md ~/.codex/skills/professor-ari-juels/SKILL.md
rsync -a skill/knowledge/ ~/.codex/skills/professor-ari-juels/knowledge/
```

Restart Codex or start a new Codex thread. Then ask for:

```text
Use the professor-ari-juels public-corpus research skill to evaluate this blockchain security research idea...
```

## Claude Code Install

Personal install:

```bash
mkdir -p ~/.claude/skills/professor-ari-juels
cp adapters/claude-code/professor-ari-juels/SKILL.md ~/.claude/skills/professor-ari-juels/SKILL.md
rsync -a skill/knowledge/ ~/.claude/skills/professor-ari-juels/knowledge/
```

Project-local install:

```bash
mkdir -p .claude/skills/professor-ari-juels
cp adapters/claude-code/professor-ari-juels/SKILL.md .claude/skills/professor-ari-juels/SKILL.md
rsync -a skill/knowledge/ .claude/skills/professor-ari-juels/knowledge/
```

Then ask Claude Code:

```text
Use the professor-ari-juels public-corpus research skill to rewrite this abstract...
```

## OpenCode Install

OpenCode supports both Markdown agents and JSON-configured agents.

### Option A: Self-contained OpenCode Agent

Install the generated agent:

```bash
mkdir -p ~/.config/opencode/agents
cp adapters/opencode/agents/ari-juels.md ~/.config/opencode/agents/ari-juels.md
```

Invoke it in OpenCode:

```text
@ari-juels evaluate this MEV research idea using the public-corpus research skill...
```

### Option B: OpenCode Command

Install the command after installing the agent:

```bash
mkdir -p ~/.config/opencode/commands
cp adapters/opencode/commands/ari-juels.md ~/.config/opencode/commands/ari-juels.md
```

Use it in the TUI:

```text
/ari-juels evaluate this oracle-security paper outline using the public-corpus research skill
```

### Option C: OpenCode JSON Config

Copy the canonical skill into your OpenCode config directory:

```bash
mkdir -p ~/.config/opencode/skills/ari-juels
cp skill/SKILL.md ~/.config/opencode/skills/ari-juels/SKILL.md
rsync -a skill/knowledge/ ~/.config/opencode/skills/ari-juels/knowledge/
```

Then merge `adapters/opencode/opencode.json.example` into `~/.config/opencode/opencode.json`.

## Aider Install

Aider does not use `SKILL.md` folders as native skills. Use the skill as a read-only conventions file:

```bash
cp skill/SKILL.md ./ARI_JUELS_SKILL.md
aider --read ./ARI_JUELS_SKILL.md
```

Inside an existing Aider session:

```text
/read ARI_JUELS_SKILL.md
```

Then prompt:

```text
Using the Ari Juels public-corpus research skill, critique this experiment design...
```

## AGENTS.md or Project-Rules Harnesses

For harnesses that load `AGENTS.md`, copy:

```bash
cp adapters/opencode/AGENTS.md ./AGENTS.md
mkdir -p ./skills/ari-juels
cp skill/SKILL.md ./skills/ari-juels/SKILL.md
rsync -a skill/knowledge/ ./skills/ari-juels/knowledge/
```

This works for agents that read project rules and can load referenced files on demand. If the harness does not automatically follow file references, paste `skill/SKILL.md` into the system or developer prompt instead.

## Generic Harness Install

Use `adapters/generic/ari-juels-full-system-prompt.md` as a system prompt or developer prompt. If your harness supports multiple prompt attachments, include `adapters/generic/ari-juels-system-prompt.md` first and then attach `skill/SKILL.md`.

Recommended invocation pattern:

```text
You have access to the Ari Juels public-corpus research skill. Follow the skill instructions exactly.
Task: <your request>
```

If the harness supports file attachments, attach:

```text
skill/SKILL.md
skill/knowledge/synthesis/evidence_map.md
skill/knowledge/synthesis/cross_paper_table.md
skill/knowledge/papers/cards/
```

Load paper cards lazily. Do not put all cards into every prompt unless the task needs paper-level auditability.

## Sharing Notes

* Share this package, not the original PDF folder.
* The package includes paraphrased paper cards and synthesis artifacts, not full papers.
* For public sharing, review `skill/knowledge/notes/` and any raw working folders before publishing.
* Do not include private correspondence, unpublished drafts, full-paper text, or private notes.
* Treat third-party skills as code-adjacent configuration: inspect the Markdown before installing.
* When this skill helps with a paper, cite the original papers where their ideas are used. Do not cite this skill as a substitute for the underlying research.

## Quick Test Prompts

```text
Use the Ari Juels public-corpus research skill to turn this idea into a security research framing: validators can privately sell ordering guarantees to latency-sensitive DeFi users.
```

```text
Use the Ari Juels public-corpus research skill to critique this paper evaluation plan: we measure only throughput and gas cost for a new oracle protocol.
```

```text
Use the Ari Juels public-corpus research skill to rewrite this abstract around the failed assumption, adversary model, and baseline.
```
