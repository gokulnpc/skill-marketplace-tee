# Source Notes

## Primary bibliography source
- DBLP profile: https://dblp.org/pid/j/AriJuels.html
- User-supplied local PDF folder, omitted from this portable package.
- Harvest report from the user's local collection, omitted from this portable package.
- Local collection manifest, omitted from this portable package.
- Refresh date: 2026-06-05

## Merge summary
- Downloaded PDFs in folder: 66.
- New synthesis cards added in this merge: 55.
- Existing synthesis duplicates skipped: 8.
- Existing held-out duplicates preserved as held-out: 3.
- DBLP deduplicated records in harvest report: 158.

## Local storage policy
- Stored notes are paraphrased.
- Full PDFs, full abstracts, long source excerpts, figure contents, and transcripts are not stored in the skill directory.
- Paper cards keep metadata and short anchors only.
