# Held-Out Paper Card

## Metadata
- Title: Resilient Alerting Protocols for Blockchains
- Year: 2026
- Venue: CoRR abs/2602.10892
- Authors: Marwa Mouallem, Lorenz Breidenbach, Ittay Eyal, Ari Juels
- Source type: held-out validation metadata and abstract

## Why held out
- Latest DBLP-visible 2026 blockchain protocol paper at refresh time.
- Tests whether the synthesized skill predicts cryptoeconomic framing, named-problem formalization, and resource-tradeoff analysis.

## Abstract-level signals
- Starts from smart contracts that need timely alerts about external events.
- Formalizes suppression via bribery as an alerting problem with rational participants.
- Presents protocols that trade synchrony assumptions, trusted hardware, proof-of-publication, storage overhead, and execution time.

## Evidence anchors
- DBLP record journals/corr/abs-2602-10892; arXiv abstract 2602.10892.
