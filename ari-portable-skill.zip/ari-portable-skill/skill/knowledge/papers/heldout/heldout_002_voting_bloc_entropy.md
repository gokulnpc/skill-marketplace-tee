# Held-Out Paper Card

## Metadata
- Title: Voting-Bloc Entropy: A New Metric for DAO Decentralization
- Year: 2025
- Venue: USENIX Security 2025
- Authors: Andres Fabrega, Amy Zhao, Jay Yu, James Austgen, Sarah Allen, Kushal Babel, Mahimna Kelkar, Ari Juels
- Source type: held-out validation metadata and abstract

## Why held out
- Recent DAO governance metric paper.
- Tests whether the synthesized skill predicts metric-building from a weak decentralization assumption.

## Abstract-level signals
- Starts from a gap in existing definitions of decentralization.
- Builds a first-principles metric from a conceptual model of voting behavior.
- Combines theory, empirical measurement, governance experiments, and open-source artifacts.

## Evidence anchors
- USENIX abstract / arXiv abstract / DBLP record.
