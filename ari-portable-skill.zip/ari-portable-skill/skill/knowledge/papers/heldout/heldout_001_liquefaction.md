# Held-Out Paper Card

## Metadata
- Title: Liquefaction: Privately Liquefying Blockchain Assets
- Year: 2025
- Venue: IEEE S&P 2025
- Authors: James Austgen, Andres Fabrega, Mahimna Kelkar, Dani Vilardell, Sarah Allen, Kushal Babel, Jay Yu, Ari Juels
- Source type: held-out validation metadata and abstract

## Why held out
- Recent boundary paper in blockchain assets, TEEs, and ownership assumptions.
- Tests whether the synthesized skill predicts assumption-breaking and TEE/blockchain hybrid framing.

## Abstract-level signals
- Starts from a foundational assumption: private keys and assets are controlled by individual entities.
- Uses TEEs to show key encumbrance can break that assumption privately.
- Discusses both harmful consequences and beneficial/countermeasure directions.

## Evidence anchors
- arXiv abstract / DBLP record.
