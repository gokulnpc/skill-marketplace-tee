# Corpus Selection

## Intake assumptions
- professor_name: Ari Juels
- institution: Cornell University / Cornell Tech
- corpus_source: D - DBLP and public paper metadata / abstracts
- paper_selection_mode: representative + held-out validation
- output_language: en
- refresh_date: 2026-06-05

## Synthesis papers
- paper_001: Coercion-resistant electronic elections, WPES 2005, DBLP https://dblp.org/rec/conf/wpes/JuelsCJ05, abstract source https://eprint.iacr.org/2002/165.pdf
- paper_002: PORs: Proofs of Retrievability for Large Files, CCS 2007, DBLP https://dblp.org/rec/conf/ccs/JuelsK07
- paper_003: A Formal Treatment of Backdoored Pseudorandom Generators, EUROCRYPT 2015 / IACR ePrint, source https://eprint.iacr.org/2016/306
- paper_004: Town Crier: An Authenticated Data Feed for Smart Contracts, CCS 2016, DBLP https://dblp.org/rec/conf/ccs/ZhangCCJS16
- paper_005: Stealing Machine Learning Models via Prediction APIs, USENIX Security 2016, source https://www.usenix.org/conference/usenixsecurity16/technical-sessions/presentation/tramer
- paper_006: Ekiden: A Platform for Confidentiality-Preserving, Trustworthy, and Performant Smart Contract Execution, EuroS&P 2019, source https://arxiv.org/abs/1804.05141
- paper_007: Flash Boys 2.0, IEEE S&P 2020, source https://arxiv.org/abs/1904.05234
- paper_008: BDoS: Blockchain Denial of Service, CoRR/IACR metadata, source https://arxiv.org/abs/1912.07497
- paper_009: Strategic Latency Reduction in Blockchain Peer-to-Peer Networks, CoRR/POMACS, source https://arxiv.org/abs/2205.06837

## Held-out papers
- heldout_001: Liquefaction: Privately Liquefying Blockchain Assets, IEEE S&P 2025, source https://arxiv.org/abs/2412.02634
- heldout_002: Voting-Bloc Entropy: A New Metric for DAO Decentralization, USENIX Security 2025, source https://www.usenix.org/conference/usenixsecurity25/presentation/fabrega
- heldout_003: Resilient Alerting Protocols for Blockchains, CoRR 2026, source https://arxiv.org/abs/2602.10892

## Candidate not carded
- The CoinAlg Bind: Profitability-Fairness Tradeoffs in Collective Investment Algorithms, CoRR 2026, source https://arxiv.org/abs/2601.00523. Recorded as a DBLP refresh signal but not added as a fourth held-out card.

## Copyright note
- No PDFs, full paper text, full abstracts, or long source excerpts are stored here.
- Paper cards preserve metadata, paraphrases, and abstract-level evidence anchors only.
