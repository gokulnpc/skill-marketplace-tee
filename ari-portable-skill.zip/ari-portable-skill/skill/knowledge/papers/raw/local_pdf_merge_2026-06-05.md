# Local PDF Merge Manifest

## Source folder
User-supplied local PDF folder, omitted from this portable package.

## Added paper cards
- paper_010: 2000 ASIACRYPT - Addition of ElGamal Plaintexts
- paper_011: 2000 ASIACRYPT - Mix and Match: Secure Function Evaluation via Ciphertexts
- paper_012: 2002 USENIX Security Symposium - Making Mix Nets Robust for Electronic Voting by Randomized Partial Checking
- paper_013: 2002 Public Key Cryptography - RSA Key Generation with Verifiable Randomness
- paper_014: 2005 SecureComm - Security and Privacy Issues in E-passports
- paper_015: 2006 Des. Codes Cryptogr. - A Fuzzy Vault Scheme
- paper_016: 2006 CHES - The Outer Limits of RFID Security
- paper_017: 2008 USENIX Security Symposium - Unidirectional Key Distribution Across Time and Space with Applications to RFID Security
- paper_018: 2009 USENIX Security Symposium - CCCP: Secure Remote Storage for Computational RFIDs
- paper_019: 2009 ACM Trans. Inf. Syst. Secur. - Defining strong privacy for RFID
- paper_020: 2009 CCS - HAIL: a high-availability and integrity layer for cloud storage
- paper_021: 2009 CCSW - Proofs of retrievability: theory and implementation
- paper_022: 2010 FAST - A Clean-Slate Look at Disk Scrubbing
- paper_023: 2010 HotSec - On the Impossibility of Cryptography Alone for Privacy-Preserving Cloud Computing
- paper_024: 2011 CCS - How to tell if your cloud files are vulnerable to drive crashes
- paper_025: 2012 GameSec - Defending against the Unknown Enemy: Applying FlipIt to System Security
- paper_026: 2012 ACSAC - Iris: a scalable cloud file system with efficient integrity checks
- paper_027: 2013 J. Cryptol. - FlipIt: The Game of "Stealthy Takeover"
- paper_028: 2013 IACR Cryptol. ePrint Arch. - Securing the Data in Big Data Security Analytics
- paper_029: 2014 IACR Cryptol. ePrint Arch. - Falcon Codes: Fast, Authenticated LT Codes
- paper_030: 2014 EUROCRYPT - Honey Encryption: Security Beyond the Brute-Force Bound
- paper_031: 2015 IEEE Symposium on Security and Privacy - Cracking-Resistant Password Vaults Using Natural Language Encoders
- paper_032: 2015 CoRR - Discovering Unwarranted Associations in Data-Driven Applications with the FairTest Testing Toolkit
- paper_033: 2015 USENIX Security Symposium - The Pythia PRF Service
- paper_034: 2016 CCS - The Ring of Gyges: Investigating the Future of Criminal Smart Contracts
- paper_035: 2017 IACR Cryptol. ePrint Arch. - A New Distribution Sensitive Secure Sketch and a Comparison Between Approaches to Typo-Tolerant Authentication
- paper_036: 2017 USENIX Security Symposium - REM: Resource-Efficient Mining for Blockchains
- paper_037: 2017 USENIX Security Symposium - ROTE: Rollback Protection for Trusted Execution
- paper_038: 2017 EuroS&P - Sealed-Glass Proofs: Using Transparent Enclaves to Prove and Sell Knowledge
- paper_039: 2017 CCS - Solidus: Confidential Distributed Ledger Transactions via PVORM
- paper_040: 2018 USENIX Security Symposium - DelegaTEE: Brokered Delegation Using Trusted Execution Environments
- paper_041: 2018 USENIX Security Symposium - Enter the Hydra: Towards Principled Bug Bounties and Exploit-Resistant Smart Contracts
- paper_042: 2018 IACR Cryptol. ePrint Arch. - Paralysis Proofs: Safe Access-Structure Updates for Cryptocurrencies and More
- paper_043: 2019 CCS - CHURP: Dynamic-Committee Proactive Secret Sharing
- paper_044: 2019 CCS - Multisketches: Practical Secure Sketches Using Off-the-Shelf Biometric Matching Algorithms
- paper_045: 2019 CCS - PIEs: Public Incompressible Encodings for Decentralized Storage
- paper_046: 2019 CoRR - SquirRL: Automating Attack Discovery on Blockchain Incentive Mechanisms with Deep Reinforcement Learning
- paper_047: 2019 CCS - Tesseract: Real-Time Cryptocurrency Exchange Using Trusted Hardware
- paper_048: 2020 CCS - DECO: Liberating Web Data Using Decentralized Oracles for TLS
- paper_049: 2020 CRYPTO (3) - Order-Fairness for Byzantine Consensus
- paper_050: 2021 SP - CanDID: Can-Do Decentralized Identity with Legacy Compatibility, Sybil-Resistance, and Accountability
- paper_051: 2023 SP - Clockwork Finance: Automated Analysis of Economic Security in Smart Contracts
- paper_052: 2023 CoRR - DAO Decentralization: Voting-Bloc Entropy, Bribery, and Dark DAOs
- paper_053: 2023 FC - Forsage: Anatomy of a Smart-Contract Pyramid Scheme
- paper_054: 2023 CCS - Lanturn: Measuring Economic Security of Smart Contracts Through Adaptive Learning
- paper_055: 2023 CoRR - Open Problems in DAOs
- paper_056: 2023 CCS - Themis: Fast, Strong Order-Fairness in Byzantine Consensus
- paper_057: 2024 CCS - Complete Knowledge: Preventing Encumbrance of Cryptographic Secrets
- paper_058: 2024 FC (2) - GoAT: File Geolocation via Anchor Timestamping
- paper_059: 2024 CoRR - PROF: Protected Order Flow in a Profit-Seeking World
- paper_060: 2024 CoRR - Props for Machine-Learning Security
- paper_061: 2024 IACR Cryptol. ePrint Arch. - The Sting Framework: Proving the Existence of Superclass Adversaries
- paper_062: 2025 CoRR - B-Privacy: Defining and Enforcing Privacy in Weighted Voting
- paper_063: 2025 CoRR - Giving AI Agents Access to Cryptocurrency and Smart Contracts Creates New Vectors of AI Harm
- paper_064: 2026 CoRR - The CoinAlg Bind: Profitability-Fairness Tradeoffs in Collective Investment Algorithms

## Skipped existing duplicates
- 2010 Towards Trustworthy Elections - Coercion-Resistant Electronic Elections: existing synthesis duplicate
- 2016 IACR Cryptol. ePrint Arch. - A Formal Treatment of Backdoored Pseudorandom Generators: existing synthesis duplicate
- 2016 USENIX Security Symposium - Stealing Machine Learning Models via Prediction APIs: existing synthesis duplicate
- 2016 CCS - Town Crier: An Authenticated Data Feed for Smart Contracts: existing synthesis duplicate
- 2018 CoRR - Ekiden: A Platform for Confidentiality-Preserving, Trustworthy, and Performant Smart Contract Execution: existing synthesis duplicate
- 2019 CoRR - Flash Boys 2.0: Frontrunning, Transaction Reordering, and Consensus Instability in Decentralized Exchanges: existing synthesis duplicate
- 2020 CCS - BDoS: Blockchain Denial-of-Service: existing synthesis duplicate
- 2023 Proc. ACM Meas. Anal. Comput. Syst. - Strategic Latency Reduction in Blockchain Peer-to-Peer Networks: existing synthesis duplicate
- 2025 SP - Liquefaction: Privately Liquefying Blockchain Assets: existing held-out duplicate
- 2025 USENIX Security Symposium - Voting-Bloc Entropy: A New Metric for DAO Decentralization: existing held-out duplicate
- 2026 CoRR - Resilient Alerting Protocols for Blockchains: existing held-out duplicate

## Copyright note
No PDF body text was copied into the skill directory. Cards contain metadata, paraphrases, and section anchors only.
