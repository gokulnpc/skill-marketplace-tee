# Paper Card

## Metadata
- Title: Ekiden: A Platform for Confidentiality-Preserving, Trustworthy, and Performant Smart Contract Execution
- Year: 2019
- Venue: IEEE EuroS&P 2019
- Authors: Raymond Cheng, Fan Zhang, Jernej Kos, Warren He, Nicholas Hynes, Noah Johnson, Ari Juels, Andrew Miller, Dawn Song
- Paper type:        system
- Area: Blockchain systems, trusted execution environments, smart-contract privacy

## Core idea
- One-sentence idea: Separate consensus from execution and use TEEs to make smart contracts private and faster.
- Problem: Blockchains give availability and integrity but expose contract data and perform poorly.
- Why the problem matters: Smart-contract adoption is limited by lack of confidentiality and scalability.
- Key insight: A TEE-backed execution layer can be paired with blockchain consensus if new hybrid attacks are addressed.
- Main contribution: Ekiden architecture, prototype, performance evidence, and analysis of TEE/blockchain pitfalls.
- What is new compared with prior work: The architecture decouples consensus and execution while explicitly treating hybrid attacks.

## Research framing
- Starting point: Smart contracts manage large value but have confidentiality and performance gaps.
- Main abstraction: Consensus layer, TEE execution node, contract state, and adversarial blockchain/TEE interaction.
- Assumptions: TEEs provide confidentiality and integrity within known limits.
- Threat model / system model / economic model: Blockchain attacks can undermine TEE-backed privacy if designs are naive.
- What is intentionally not modeled: Metadata-only card; detailed protocol proofs are not inspected.
- Success criterion: Confidential and scalable execution with identified hybrid risks handled.

## Method
- Main technique: System architecture and prototype measurement with Tendermint-style consensus.
- Theory / system / measurement / empirical / mixed: mixed system.
- Why the method fits the problem: The claim requires a working platform and analysis of trust boundaries.

## Experiments or evaluation
- Datasets: prototype workloads, not fully inspected.
- Baselines: Ethereum mainnet-style performance and cost.
- Metrics: throughput, latency, cost, confidentiality support.
- Ablations: n/a from metadata.
- Robustness checks: identifies hybrid TEE/blockchain attack pitfalls.
- Case studies: private smart-contract execution.
- Negative results or failure cases: naive TEE-blockchain designs can leak privacy through unrelated blockchain attacks.
- Reproducibility details: prototype reported; code not inspected.

## Presentation
- Intro pattern: deployment promise followed by two blocking gaps.
- Motivating example: smart contracts managing value but lacking confidentiality/performance - evidence: arXiv abstract.
- Main figures / tables: n/a from metadata.
- How claims are scoped: system performance and pitfall treatment - evidence: arXiv abstract.

## Writing structure
- Abstract structure: system importance, gaps, architecture, prototype results, hybrid risks.
- Introduction structure: n/a from metadata.
- Contribution list style: inline from abstract-level evidence.
- Related work placement: n/a.
- Evaluation narrative: architecture plus performance plus security pitfalls.
- Limitations style: explicit attention to hybrid-system pitfalls.

## Extracted research-skill signals
- High-level idea style: find the hidden conflict between desirable system properties - evidence: arXiv abstract.
- Research framing signal: separates consensus and execution to reveal trust boundaries - evidence: arXiv abstract.
- Method signal: validates architecture with a prototype and quantified comparison - evidence: arXiv abstract.
- Experimental standard signal: compares to an obvious deployed baseline and reports throughput, latency, and cost - evidence: arXiv abstract.
- Presentation signal: uses promise-gap-architecture-risk sequence - evidence: arXiv abstract.
- Writing signal: includes pitfalls as a first-class contribution - evidence: arXiv abstract.
- Confidence:                      direct evidence.
- Coauthor attribution risk:       high - nine-author systems paper.
- Evidence anchors:                arXiv abstract, venue metadata.
