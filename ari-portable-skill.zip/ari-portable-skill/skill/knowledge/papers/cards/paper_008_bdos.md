# Paper Card

## Metadata
- Title: BDoS: Blockchain Denial of Service
- Year: 2019 / 2020
- Venue: CoRR / IACR ePrint metadata
- Authors: Michael Mirkin, Yan Ji, Jonathan Pang, Ariah Klages-Mundt, Ittay Eyal, Ari Juels
- Paper type:        mechanism-design attack
- Area: Blockchain security, proof-of-work incentives

## Core idea
- One-sentence idea: Denial-of-service against proof-of-work cryptocurrencies can target miner incentives rather than network servers.
- Problem: Classical DoS models do not scale naturally to widely replicated cryptocurrency networks.
- Why the problem matters: PoW systems secure large value and may be attacked for competition or short-selling motives.
- Key insight: Exploit the reward mechanism to discourage miners from participating.
- Main contribution: BDoS as an incentive-based attack model for PoW blockchains.
- What is new compared with prior work: Reframes DoS from traffic exhaustion to mechanism-design exploitation.

## Research framing
- Starting point: Prominent cryptocurrencies have many nodes and no known successful classical DoS attacks.
- Main abstraction: Miner, reward mechanism, attacker incentives, participation decision.
- Assumptions: Miner behavior responds to expected rewards and attack-induced incentives.
- Threat model / system model / economic model: Attacker targets incentive compatibility rather than individual servers.
- What is intentionally not modeled: Metadata-only card; detailed proofs and simulations not inspected.
- Success criterion: Show a plausible DoS route through mechanism design.

## Method
- Main technique: Incentive/security analysis of PoW reward mechanisms.
- Theory / system / measurement / empirical / mixed: mixed model / attack.
- Why the method fits the problem: The attack lives in miner incentives, not packet-level traffic.

## Experiments or evaluation
- Datasets: n/a from metadata.
- Baselines: classical DoS against servers; ordinary PoW mining incentives.
- Metrics: miner participation and attack viability, not fully inspected.
- Ablations: n/a from metadata.
- Robustness checks: n/a from metadata.
- Case studies: PoW cryptocurrency blockchains.
- Negative results or failure cases: classical DoS is a poor fit for replicated blockchains.
- Reproducibility details: n/a from metadata.

## Presentation
- Intro pattern: classical analogy first, then blockchain-specific failure.
- Motivating example: miners withdrawing participation under distorted rewards - evidence: abstract.
- Main figures / tables: n/a from metadata.
- How claims are scoped: PoW cryptocurrencies and reward mechanisms - evidence: abstract.

## Writing structure
- Abstract structure: system value, classical attack mismatch, new attack, mechanism-design explanation.
- Introduction structure: n/a from metadata.
- Contribution list style: inline from abstract-level evidence.
- Related work placement: n/a.
- Evaluation narrative: mechanism first.
- Limitations style: n/a from metadata.

## Extracted research-skill signals
- High-level idea style: replace a network-security framing with an incentive-security framing - evidence: abstract.
- Research framing signal: models miner participation as the attack surface - evidence: abstract.
- Method signal: adapts mechanism-design reasoning to denial of service - evidence: abstract.
- Experimental standard signal: low-confidence; metadata does not expose the evaluation details - evidence: abstract.
- Presentation signal: contrasts classical DoS with blockchain DoS - evidence: abstract.
- Writing signal: defines a new named attack after explaining why old models fail - evidence: abstract.
- Confidence:                      direct evidence.
- Coauthor attribution risk:       high - six-author blockchain incentive paper.
- Evidence anchors:                abstract, DBLP record.
