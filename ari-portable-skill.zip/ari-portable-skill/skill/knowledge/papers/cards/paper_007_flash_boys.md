# Paper Card

## Metadata
- Title: Flash Boys 2.0: Frontrunning in Decentralized Exchanges, Miner Extractable Value, and Consensus Instability
- Year: 2020
- Venue: IEEE S&P 2020
- Authors: Philip Daian, Steven Goldfeder, Tyler Kell, Yunqi Li, Xueyuan Zhao, Iddo Bentov, Lorenz Breidenbach, Ari Juels
- Paper type:        empirical / measurement / game-theoretic
- Area: Blockchain security, DeFi, MEV

## Core idea
- One-sentence idea: DEX arbitrage and priority gas auctions reveal MEV as a measurable consensus-layer security risk.
- Problem: Smart contracts promised fair markets, but transaction ordering creates exploitable opportunities.
- Why the problem matters: Arbitrage bots and fee bidding can harm users and destabilize consensus incentives.
- Key insight: Model and measure priority gas auctions as a blockchain-native market microstructure problem.
- Main contribution: Empirical documentation of bots, formal PGA model, real-time portal, and MEV risk framing.
- What is new compared with prior work: Connects application-layer frontrunning to consensus-layer security risks.

## Research framing
- Starting point: DEXes are transparent and ordered by miners/validators.
- Main abstraction: Arbitrage bot, ordinary user, priority gas auction, miner extractable value, consensus risk.
- Assumptions: Transaction ordering has economic value and can be competitively bid for.
- Threat model / system model / economic model: Strategic bots and miners exploit ordering dependencies.
- What is intentionally not modeled: Metadata-only card; detailed datasets and portal behavior not inspected.
- Success criterion: Quantify and explain a real ordering-risk phenomenon.

## Method
- Main technique: On-chain measurement plus game-theoretic modeling.
- Theory / system / measurement / empirical / mixed: mixed empirical / game-theoretic.
- Why the method fits the problem: MEV is both a measurable empirical phenomenon and an incentive problem.

## Experiments or evaluation
- Datasets: subset of DEX transactions with quantifiable bot revenue.
- Baselines: fair/transparent trading expectation and ordinary transaction fee behavior.
- Metrics: bot revenue, priority fee dynamics, latency-like ordering advantage, consensus risk.
- Ablations: n/a from metadata.
- Robustness checks: links fees and ordering dependencies to broader DEX/consensus conditions.
- Case studies: DEX arbitrage and priority gas auctions.
- Negative results or failure cases: fairness promise fails under transaction-ordering exploitation.
- Reproducibility details: public portal was released according to abstract-level evidence.

## Presentation
- Intro pattern: promise-versus-failure.
- Motivating example: high-frequency-like bots in DEXes - evidence: arXiv abstract.
- Main figures / tables: n/a from metadata.
- How claims are scoped: empirical subset plus general MEV framing - evidence: arXiv abstract.

## Writing structure
- Abstract structure: promise, empirical failure, model, artifact, systemic implication.
- Introduction structure: n/a from metadata.
- Contribution list style: inline from abstract-level evidence.
- Related work placement: n/a.
- Evaluation narrative: measurement leads to model and systemic risk.
- Limitations style: scope is tied to measurable transactions and realistic Ethereum threat.

## Extracted research-skill signals
- High-level idea style: identify when an application-level market failure feeds back into infrastructure security - evidence: arXiv abstract.
- Research framing signal: formalizes a new economic object after observing it empirically - evidence: arXiv abstract.
- Method signal: combines measurement, model, and public artifact - evidence: arXiv abstract.
- Experimental standard signal: requires quantifiable revenue and real transactions - evidence: arXiv abstract.
- Presentation signal: uses a vivid analogy to traditional market exploitation - evidence: arXiv abstract.
- Writing signal: ends with broad security implication grounded in measurement - evidence: arXiv abstract.
- Confidence:                      direct evidence.
- Coauthor attribution risk:       high - large multi-author blockchain paper.
- Evidence anchors:                arXiv abstract, DBLP record.
