# Paper Card

## Metadata
- Title: Coercion-resistant electronic elections
- Year: 2005
- Venue: WPES 2005
- Authors: Ari Juels, Dario Catalano, Markus Jakobsson
- Paper type:        theory / protocol
- Area: Electronic voting, applied cryptography

## Core idea
- One-sentence idea: Define and construct election schemes resilient to stronger coercion behaviors than receipt-freeness covers.
- Problem: Internet voting can let adversaries demand votes, abstention, or secret-key disclosure.
- Why the problem matters: The voting system fails if a coerced voter can prove compliance to a coercer.
- Key insight: Model coercion through adversarial demands and require that compliance be infeasible to determine.
- Main contribution: A formal security framework and a scheme intended to satisfy coercion resistance, correctness, and verifiability.
- What is new compared with prior work: The adversary model includes forced abstention, randomization, and simulation-style coercion.

## Research framing
- Starting point: A real voting workflow where voters may interact remotely and coercers can inspect private material.
- Main abstraction: Coercer, voter, tallying authorities, and indistinguishability of compliance.
- Assumptions: Anonymous channel availability and limited authority corruption in the model.
- Threat model / system model / economic model: Coercion adversary can demand actions and secrets from voters.
- What is intentionally not modeled: Metadata-only card; full implementation details are not analyzed.
- Success criterion: Coercer cannot determine whether a voter complied.

## Method
- Main technique: Formal definitions plus protocol construction.
- Theory / system / measurement / empirical / mixed: theory.
- Why the method fits the problem: The core issue is a security property, so definitions and constructions are primary.

## Experiments or evaluation
- Datasets: n/a.
- Baselines: receipt-freeness and prior electronic election schemes.
- Metrics: security properties, not empirical metrics.
- Ablations: n/a.
- Robustness checks: model considers stronger coercive behaviors.
- Case studies: n/a.
- Negative results or failure cases: prior schemes can fail under private-key disclosure or simulation demands.
- Reproducibility details: n/a.

## Presentation
- Intro pattern: threat-first / definition-first.
- Motivating example: coerced voters and secret-key disclosure - evidence: abstract.
- Main figures / tables: n/a from metadata.
- How claims are scoped: property-scoped around coercion resistance - evidence: abstract.

## Writing structure
- Abstract structure: adversary expansion, definition, construction.
- Introduction structure: n/a from metadata.
- Contribution list style: inline from abstract-level evidence.
- Related work placement: n/a.
- Evaluation narrative: by security property.
- Limitations style: assumptions visible at abstract level; full limits not available.

## Extracted research-skill signals
- High-level idea style: strengthen a real adversary until prior properties are insufficient - evidence: abstract.
- Research framing signal: formalize the adversary before introducing the scheme - evidence: abstract.
- Method signal: uses security definitions as the main research object - evidence: abstract.
- Experimental standard signal: theoretical property replaces empirical evaluation - evidence: venue/type metadata.
- Presentation signal: opens from a stronger threat model - evidence: abstract.
- Writing signal: states model contribution before construction - evidence: abstract.
- Confidence:                      direct evidence.
- Coauthor attribution risk:       medium - three-author paper, signals may be shared.
- Evidence anchors:                abstract, DBLP record.
