# Paper Card

## Metadata
- Title: PORs: Proofs of Retrievability for Large Files
- Year: 2007
- Venue: CCS 2007
- Authors: Ari Juels, Burton S. Kaliski Jr.
- Paper type:        theory / protocol
- Area: Cloud-storage integrity, applied cryptography

## Core idea
- One-sentence idea: Let a verifier check that an archive can still return a large file without downloading it.
- Problem: Users need assurance that outsourced archives retain enough data for recovery.
- Why the problem matters: Full retrieval is expensive and naive integrity checks may not prove recoverability.
- Key insight: Treat retrievability as a specialized proof-like protocol optimized for large files.
- Main contribution: Practical POR constructions with small verifier storage and communication relative to file size.
- What is new compared with prior work: The framing focuses on recoverability of full files rather than only possession of pieces.

## Research framing
- Starting point: Archive or backup services that may delete or corrupt user data.
- Main abstraction: Prover archive, verifier user, target file, and concise challenge-response proof.
- Assumptions: File is encoded or prepared for later checking.
- Threat model / system model / economic model: Storage service may fail to retain enough information to recover the file.
- What is intentionally not modeled: Metadata-only card; detailed protocol variants are not analyzed.
- Success criterion: Verifier gains evidence that the file remains retrievable.

## Method
- Main technique: Cryptographic protocol design with efficiency constraints.
- Theory / system / measurement / empirical / mixed: theory with practical design considerations.
- Why the method fits the problem: The task needs a protocol guarantee whose costs scale weakly with file size.

## Experiments or evaluation
- Datasets: n/a.
- Baselines: prior proof-of-knowledge and storage-checking schemes.
- Metrics: communication, memory access, verifier storage, and user storage overhead.
- Ablations: n/a.
- Robustness checks: construction-level security considerations.
- Case studies: archive / backup service.
- Negative results or failure cases: archives may retain insufficient data without detection.
- Reproducibility details: n/a.

## Presentation
- Intro pattern: problem-definition first.
- Motivating example: archive or backup service retaining a large file - evidence: abstract.
- Main figures / tables: n/a from metadata.
- How claims are scoped: efficiency and retrievability are both named - evidence: abstract.

## Writing structure
- Abstract structure: definition, protocol role, efficiency target, construction.
- Introduction structure: n/a from metadata.
- Contribution list style: inline from abstract-level evidence.
- Related work placement: n/a.
- Evaluation narrative: cost and guarantee driven.
- Limitations style: n/a from metadata.

## Extracted research-skill signals
- High-level idea style: turn a practical outsourcing worry into a named cryptographic primitive - evidence: abstract.
- Research framing signal: separates prover and verifier roles cleanly - evidence: abstract.
- Method signal: optimizes for communication and storage constraints as first-class design goals - evidence: abstract.
- Experimental standard signal: evaluates by asymptotic and practical overhead rather than datasets - evidence: abstract.
- Presentation signal: starts from a user-facing service problem and names the primitive - evidence: abstract.
- Writing signal: introduces definition and constraints before constructions - evidence: abstract.
- Confidence:                      direct evidence.
- Coauthor attribution risk:       medium - two-author applied-crypto paper.
- Evidence anchors:                abstract, DBLP record.
