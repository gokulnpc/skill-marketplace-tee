# Paper Card

## Metadata
- Title: Town Crier: An Authenticated Data Feed for Smart Contracts
- Year: 2016
- Venue: CCS 2016
- Authors: Fan Zhang, Ethan Cecchetti, Kyle Croman, Ari Juels, Elaine Shi
- Paper type:        system / formal model
- Area: Smart-contract oracles, trusted hardware, blockchain systems

## Core idea
- One-sentence idea: Bridge smart contracts to HTTPS data through an SGX-backed authenticated data feed.
- Problem: Smart contracts need real-world data but ordinary data feeds require trust in operators.
- Why the problem matters: Financial and other contracts cannot safely execute if input data lacks source authentication or confidentiality.
- Key insight: Combine a blockchain front end with a trusted-hardware back end that fetches authenticated web data.
- Main contribution: Town Crier system design, implementation, security model, and experiments.
- What is new compared with prior work: It connects existing HTTPS trust roots to smart contracts while minimizing operator trust.

## Research framing
- Starting point: Smart contracts are autonomous but isolated from real-world state.
- Main abstraction: Smart-contract client, TC contract, SGX-protected server, HTTPS data source.
- Assumptions: Trusted hardware and TLS endpoints can authenticate data in the modeled setting.
- Threat model / system model / economic model: Operator should not be trusted to fabricate or inspect protected query data.
- What is intentionally not modeled: Metadata-only card; detailed UC model is not analyzed.
- Success criterion: Source-authenticated data and private requests become usable by smart contracts.

## Method
- Main technique: System architecture using blockchain plus SGX, with formal modeling.
- Theory / system / measurement / empirical / mixed: mixed.
- Why the method fits the problem: The oracle gap requires both a deployable bridge and a security model.

## Experiments or evaluation
- Datasets: example applications from paper abstract-level evidence.
- Baselines: ordinary data feeds and operator-reputation trust.
- Metrics: source authentication, confidentiality, gas/resource considerations, application feasibility.
- Ablations: n/a from metadata.
- Robustness checks: TCB minimization is identified as a concern.
- Case studies: smart-contract applications consuming external data.
- Negative results or failure cases: ordinary blockchain-only contracts cannot verify external events alone.
- Reproducibility details: implementation reported; code details not inspected.

## Presentation
- Intro pattern: deployment gap first.
- Motivating example: financial smart contracts needing stock-price-like data - evidence: abstract.
- Main figures / tables: n/a from metadata.
- How claims are scoped: system and model claims tied to SGX and HTTPS - evidence: abstract.

## Writing structure
- Abstract structure: system need, oracle gap, architecture, formal model, experiments.
- Introduction structure: n/a from metadata.
- Contribution list style: inline from abstract-level evidence.
- Related work placement: n/a.
- Evaluation narrative: architecture then applications.
- Limitations style: TCB and resource-consumption concerns named at abstract level.

## Extracted research-skill signals
- High-level idea style: turn a missing trust boundary into an architecture - evidence: abstract.
- Research framing signal: isolates trusted hardware and operator trust as model boundaries - evidence: abstract.
- Method signal: combines system implementation with formal model - evidence: abstract.
- Experimental standard signal: uses applications and resource concerns as evaluation hooks - evidence: abstract.
- Presentation signal: starts from smart-contract usefulness blocked by off-chain data - evidence: abstract.
- Writing signal: explains architecture before broad implications - evidence: abstract.
- Confidence:                      direct evidence.
- Coauthor attribution risk:       high - multi-author IC3/Cornell systems paper.
- Evidence anchors:                abstract, DBLP record.
