# Paper Card

## Metadata
- Title: A Formal Treatment of Backdoored Pseudorandom Generators
- Year: 2015
- Venue: EUROCRYPT 2015 / IACR ePrint 2016/306
- Authors: Yevgeniy Dodis, Chaya Ganesh, Alexander Golovnev, Ari Juels, Thomas Ristenpart
- Paper type:        theory
- Area: Cryptographic subversion, pseudorandomness

## Core idea
- One-sentence idea: Formalize PRGs with trapdoors and connect them to public-key encryption with pseudorandom ciphertexts.
- Problem: Backdoored PRGs such as Dual EC require a general treatment of construction, detection, and immunization.
- Why the problem matters: Protocols can be subverted through randomness generators that look normal without the trapdoor.
- Key insight: Backdoored PRGs can be characterized through an equivalence with encryption objects.
- Main contribution: Formal definitions, constructions, explanatory framework, and immunizer analysis.
- What is new compared with prior work: Goes beyond limited trapdoored-generator models and analyzes protocol subversion and countermeasures.

## Research framing
- Starting point: Public concern and technical evidence around backdoored randomness.
- Main abstraction: Saboteur, PRG instance, trapdoor, outputs, immunizer.
- Assumptions: Formal cryptographic assumptions around indistinguishability and extraction.
- Threat model / system model / economic model: Saboteur creates a generator whose outputs can be predicted with trapdoor knowledge.
- What is intentionally not modeled: Deployment prevalence of real backdoors.
- Success criterion: Clarify when backdoored PRGs exist, how they relate to encryption, and which immunizers work.

## Method
- Main technique: Formal definitions, equivalence proofs, constructions, and countermeasure proofs.
- Theory / system / measurement / empirical / mixed: theory.
- Why the method fits the problem: The core contribution is conceptual and proof-based.

## Experiments or evaluation
- Datasets: n/a.
- Baselines: prior Vazirani-style trapdoored generator work and Dual EC-style concerns.
- Metrics: security definitions and proof outcomes.
- Ablations: n/a.
- Robustness checks: tests folklore immunizer suggestions under formal models.
- Case studies: Dual EC is a motivating case.
- Negative results or failure cases: simple hashing is not a sufficient immunizer in the modeled setting.
- Reproducibility details: n/a.

## Presentation
- Intro pattern: event-driven threat first, then formal model.
- Motivating example: Dual EC backdoor concern - evidence: IACR abstract.
- Main figures / tables: n/a from metadata.
- How claims are scoped: formal claims tied to equivalence and immunizer models - evidence: IACR abstract.

## Writing structure
- Abstract structure: motivation, formal equivalence, constructions, countermeasures.
- Introduction structure: n/a from metadata.
- Contribution list style: inline from abstract-level evidence.
- Related work placement: n/a.
- Evaluation narrative: proof and counterexample sequence.
- Limitations style: scoped by formal model.

## Extracted research-skill signals
- High-level idea style: convert a public subversion concern into a precise cryptographic object - evidence: IACR abstract.
- Research framing signal: explicitly models the saboteur and trapdoor - evidence: IACR abstract.
- Method signal: uses equivalence to known primitives as an explanatory tool - evidence: IACR abstract.
- Experimental standard signal: evaluates countermeasures through proof rather than experiment - evidence: IACR abstract.
- Presentation signal: pairs real-world motivation with formal treatment - evidence: IACR abstract.
- Writing signal: moves from equivalence to constructions to immunizers - evidence: IACR abstract.
- Confidence:                      direct evidence.
- Coauthor attribution risk:       high - five coauthors and theory-heavy contributions.
- Evidence anchors:                IACR abstract, metadata.
