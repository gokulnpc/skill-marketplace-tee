# Paper Card

## Metadata
- Title: Complete Knowledge: Preventing Encumbrance of Cryptographic Secrets
- Year: 2024
- Venue: CCS
- Authors: Mahimna Kelkar, Kushal Babel, Philip Daian, James Austgen, Vitalik Buterin, Ari Juels
- Paper type:        theory / protocol
- Area: Applied cryptography and cryptographic protocol design

## Core idea
- One-sentence idea: Extracts a security-relevant model or mechanism in applied cryptography and cryptographic protocol design.
- Problem: The paper identifies a concrete security, privacy, reliability, fairness, or incentive gap in its target system or primitive.
- Why the problem matters: The gap changes what users, operators, or protocols can safely assume.
- Key insight: Reframe the gap as a formal property, adversarial model, measurement target, or deployable mechanism.
- Main contribution: Extracts a security-relevant model or mechanism in applied cryptography and cryptographic protocol design.
- What is new compared with prior work: It narrows a broad security concern into a specific model, construction, metric, or evaluation target.

## Research framing
- Starting point: A formal or protocol-level security gap visible from the title, metadata, and PDF front matter.
- Main abstraction: Roles and assumptions are named around the target system, adversary, verifier, user, or strategic participant.
- Assumptions: Use the paper-specific trust, cryptographic, hardware, or economic assumptions rather than a generic attacker model.
- Threat model / system model / economic model: The model is tied to applied cryptography and cryptographic protocol design.
- What is intentionally not modeled: This card stores only metadata, paraphrased abstract/front-matter signals, and section anchors, not full paper text.
- Success criterion: A reader can tell what property, mechanism, measurement, or attack the paper adds beyond the baseline.

## Method
- Main technique: Cryptographic or systems construction with model-driven security analysis.
- Theory / system / measurement / empirical / mixed: theory / protocol
- Why the method fits the problem: The method follows from whether the gap is formal, operational, empirical, or incentive-driven.

## Experiments or evaluation
- Datasets: n/a or paper-specific workloads, depending on the paper type.
- Baselines: the natural prior protocol, deployed system, or formal primitive.
- Metrics: Security property, cost, performance, privacy, fairness, robustness, or economic outcome as appropriate to the title and area.
- Ablations: Record only if the paper has separable system mechanisms; otherwise n/a.
- Robustness checks: Look for countermeasures, model-boundary tests, or adversary variations.
- Case studies: Paper-specific examples from the target domain.
- Negative results or failure cases: Treat any stated impossibility, tradeoff, attack, or limitation as first-class evidence.
- Reproducibility details: Local PDF exists in the supplied folder; no code/artifact inspection was performed.

## Presentation
- Intro pattern:                  problem-first.
- Motivating example:             The target system or primitive named by the title, with front-matter evidence.
- Main figures / tables:          Use the full PDF for figure/table anchors when needed; this card does not store figure content.
- How claims are scoped:          Scoped to the model, primitive, mechanism, or empirical setting; evidence: 3 PRELIMINARIES AND BACKGROUND.

## Writing structure
- Abstract structure: Problem/gap, model or mechanism, contribution, and evidence/tradeoff.
- Introduction structure: problem-first, followed by model or mechanism details.
- Contribution list style:        inspect full PDF if exact numbered/bulleted format is required.
- Related work placement:         n/a from card-level extraction.
- Evaluation narrative:           by-claim for empirical/systems papers; by-definition or by-theorem for formal papers.
- Limitations style:              explicit when the paper centers an impossibility, tradeoff, countermeasure, or model boundary; otherwise inspect full PDF.

## Extracted research-skill signals
- High-level idea style:           converts a concrete security or trust failure into an analyzable object — evidence: title/front matter, 3 PRELIMINARIES AND BACKGROUND.
- Research framing signal:         names the target roles and assumptions before method details — evidence: 3 PRELIMINARIES AND BACKGROUND.
- Method signal:                   chooses formal modeling, system building, measurement, or game/economic analysis to match the failure mode — evidence: title/front matter.
- Experimental standard signal:    compares against the natural prior protocol, deployed system, or formal primitive. — evidence: metadata/front matter.
- Presentation signal:             opens from problem-first framing — evidence: title/front matter, 3 PRELIMINARIES AND BACKGROUND.
- Writing signal:                  moves from problem framing to model/mechanism/evidence — evidence: PDF front matter and section headings.
- Confidence:                      direct evidence.
- Coauthor attribution risk:       high — 6-author paper; signals may reflect coauthors and venue norms.
- Evidence anchors:                title page, abstract/front matter, 3 PRELIMINARIES AND BACKGROUND; DOI 10.1145/3658644.3690273; arXiv n/a.
