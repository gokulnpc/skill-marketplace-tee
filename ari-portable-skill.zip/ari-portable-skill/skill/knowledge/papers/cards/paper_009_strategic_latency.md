# Paper Card

## Metadata
- Title: Strategic Latency Reduction in Blockchain Peer-to-Peer Networks
- Year: 2022 / 2023
- Venue: CoRR / POMACS 2023
- Authors: Weizhao Tang, Lucianna Kiffer, Giulia Fanti, Ari Juels
- Paper type:        measurement / theory
- Area: Blockchain P2P networks, latency manipulation

## Core idea
- One-sentence idea: Blockchain users can strategically manipulate local peering decisions to reduce latency and gain economic advantage.
- Problem: P2P decentralization trades off performance, and DeFi makes latency economically valuable.
- Why the problem matters: Local network choices can create fairness and privacy risks at the application layer.
- Key insight: Even limited peering control can capture a substantial portion of centralized latency gains.
- Main contribution: Latency classes, empirical manipulation results, and a theoretical model showing unavoidable strategic latency opportunities under churn/activity.
- What is new compared with prior work: Treats latency as a strategic adversarial resource in blockchain P2P networks.

## Research framing
- Starting point: Permissionless blockchains rely on flexible P2P networks.
- Main abstraction: Strategic agent, peering decisions, latency classes, peer churn, transaction activity.
- Assumptions: Agent can control local peering and latency affects payoff.
- Threat model / system model / economic model: Rational users manipulate network position for advantage.
- What is intentionally not modeled: Metadata-only card; detailed network model not inspected.
- Success criterion: Demonstrate and theoretically explain strategic latency gains.

## Method
- Main technique: Empirical network manipulation plus simple theoretical model.
- Theory / system / measurement / empirical / mixed: mixed measurement / theory.
- Why the method fits the problem: The question is both operational and structural.

## Experiments or evaluation
- Datasets: blockchain P2P network measurements, not fully inspected.
- Baselines: centralized paid latency service and existing P2P behavior.
- Metrics: latency gain, targeted latency gain, fraction of centralized service benefit.
- Ablations: n/a from metadata.
- Robustness checks: theoretical proof under peer churn and transaction activity assumptions.
- Case studies: latency-sensitive blockchain applications such as DeFi.
- Negative results or failure cases: results are not only due to poor existing P2P design.
- Reproducibility details: n/a from metadata.

## Presentation
- Intro pattern: emerging application pressure changes old tradeoff.
- Motivating example: DeFi users gaining by lowering latency - evidence: arXiv abstract.
- Main figures / tables: n/a from metadata.
- How claims are scoped: sufficient peer churn and transaction activity - evidence: arXiv abstract.

## Writing structure
- Abstract structure: system tradeoff, new economic pressure, definitions, empirical result, theory result.
- Introduction structure: n/a from metadata.
- Contribution list style: inline from abstract-level evidence.
- Related work placement: n/a.
- Evaluation narrative: define latency types, measure manipulation, then prove structural risk.
- Limitations style: conditions stated for theoretical claim.

## Extracted research-skill signals
- High-level idea style: detect when a formerly tolerable systems tradeoff becomes security-critical because incentives changed - evidence: arXiv abstract.
- Research framing signal: defines the adversary through local control rather than global compromise - evidence: arXiv abstract.
- Method signal: pairs empirical gains with a model explaining why they are structural - evidence: arXiv abstract.
- Experimental standard signal: compares against both current P2P behavior and centralized latency service - evidence: arXiv abstract.
- Presentation signal: motivates from application pressure and then defines technical latency classes - evidence: arXiv abstract.
- Writing signal: ends with implications for fairness and privacy at higher layers - evidence: arXiv abstract.
- Confidence:                      direct evidence.
- Coauthor attribution risk:       high - four-author measurement/theory paper.
- Evidence anchors:                arXiv abstract, ETH metadata, DBLP record.
