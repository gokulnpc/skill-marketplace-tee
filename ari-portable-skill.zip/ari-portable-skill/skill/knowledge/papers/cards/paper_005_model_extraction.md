# Paper Card

## Metadata
- Title: Stealing Machine Learning Models via Prediction APIs
- Year: 2016
- Venue: USENIX Security 2016
- Authors: Florian Tramer, Fan Zhang, Ari Juels, Michael K. Reiter, Thomas Ristenpart
- Paper type:        empirical / attack
- Area: Machine-learning security

## Core idea
- One-sentence idea: Black-box prediction APIs can leak enough information for attackers to extract high-fidelity substitute models.
- Problem: Confidential ML models are exposed through public query interfaces.
- Why the problem matters: Model theft can harm commercial value, privacy, and downstream security.
- Key insight: API practices such as confidence outputs and partial feature vectors create efficient extraction channels.
- Main contribution: Practical extraction attacks for multiple model classes and deployed MLaaS providers.
- What is new compared with prior work: Demonstrates model extraction outside classical learning-theory assumptions and against real services.

## Research framing
- Starting point: MLaaS exposes confidential models through paid or public prediction APIs.
- Main abstraction: Black-box adversary, target model, query interface, substitute model fidelity.
- Assumptions: Attacker can issue enough queries and observe prediction outputs.
- Threat model / system model / economic model: Model owner wants confidentiality while API reveals predictions.
- What is intentionally not modeled: Full training-data recovery is not the core claim in the abstract.
- Success criterion: Extracted model approximates target functionality with high fidelity.

## Method
- Main technique: Query-based attacks and empirical evaluation against services.
- Theory / system / measurement / empirical / mixed: empirical / attack.
- Why the method fits the problem: The question is whether deployed APIs leak enough to steal functionality.

## Experiments or evaluation
- Datasets: service-specific and model-class-specific test tasks, not fully inspected.
- Baselines: target MLaaS models and countermeasure of omitting confidence values.
- Metrics: model fidelity, query efficiency, model class coverage.
- Ablations: confidence-output removal is considered as a countermeasure.
- Robustness checks: attacks still work under a natural output-suppression countermeasure.
- Case studies: BigML and Amazon Machine Learning.
- Negative results or failure cases: omitting confidence values is insufficient as a general defense.
- Reproducibility details: paper and proceedings are open access; exact artifacts not inspected.

## Presentation
- Intro pattern: confidentiality tension first.
- Motivating example: MLaaS prediction APIs - evidence: USENIX abstract.
- Main figures / tables: n/a from metadata.
- How claims are scoped: black-box API model and tested providers - evidence: USENIX abstract.

## Writing structure
- Abstract structure: asset at risk, interface tension, attack model, empirical results, defense implication.
- Introduction structure: n/a from metadata.
- Contribution list style: inline from abstract-level evidence.
- Related work placement: n/a.
- Evaluation narrative: by model class and service.
- Limitations style: natural countermeasure discussed.

## Extracted research-skill signals
- High-level idea style: look for leakage created by a public interface to a valuable black box - evidence: USENIX abstract.
- Research framing signal: defines attack through interface access rather than internal access - evidence: USENIX abstract.
- Method signal: validates attack on real commercial-style services - evidence: USENIX abstract.
- Experimental standard signal: includes model classes, deployed providers, and countermeasure check - evidence: USENIX abstract.
- Presentation signal: opens with confidentiality-versus-access tension - evidence: USENIX abstract.
- Writing signal: ends abstract with deployment caution and countermeasure need - evidence: USENIX abstract.
- Confidence:                      direct evidence.
- Coauthor attribution risk:       high - five coauthors and cross-institution attack work.
- Evidence anchors:                USENIX abstract, DBLP record.
