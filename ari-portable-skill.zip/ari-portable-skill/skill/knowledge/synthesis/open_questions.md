# Open Questions

## Open questions
- Which patterns are Ari Juels-specific rather than coauthor, venue, or IC3/Cornell-specific?
  - Why open: high coauthor attribution risk across most systems and blockchain papers.
  - What would resolve it: compare with coauthors' independent papers and Ari Juels solo-authored technical writing.
- Do full papers share a precise contribution-list, related-work, and figure-caption convention?
  - Why open: the merge kept cards and anchors, not full paper text or figure contents.
  - What would resolve it: a separate style-only pass over full PDFs with copyright-safe figure/table anchors.
- How should missing DBLP records without downloaded PDFs alter early-career and RFID conclusions?
  - Why open: the harvested folder downloaded 66 of 158 deduplicated records.
  - What would resolve it: add local PDFs or metadata for missing records listed in the harvest report.
- Are AI-agent/crypto harms and CoinAlg papers a new branch or continuation of the existing cryptoeconomic framing?
  - Why open: paper_063 and paper_064 are recent and currently low-to-medium confidence as a time-varying direction.
  - What would resolve it: add more 2025-2026 follow-up papers and held-out validation after they mature.
