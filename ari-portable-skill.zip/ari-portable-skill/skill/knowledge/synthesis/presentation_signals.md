# Presentation Signals

## 1. Opening motivation
The expanded PDF corpus supports a stable deployment-first or threat-first opening for systems, RFID, storage, ML, and blockchain papers: paper_014, paper_017-paper_024, paper_032-paper_034, paper_036-paper_064. Formal crypto papers often begin definition-first while still motivating from a concrete gap: paper_010, paper_011, paper_013, paper_015, paper_029, paper_030, paper_043.

## 2. Use of examples
Examples are usually concrete artifacts: RFID tags/e-passports, cloud files/drives, password vaults, trusted enclaves, smart contracts, DAOs, DEXes, order flow, and collective investment algorithms. Evidence: paper_014-paper_024, paper_031-paper_064.

## 3. Figure placement
Low-confidence: this merge did not store figure content or page-level screenshots. Use paper-specific PDF inspection before imitating hero figure placement or caption style.

## 4. Theorem / system / experiment ordering
Formal papers tend to put definitions and models before construction (paper_010, paper_011, paper_013, paper_015, paper_027, paper_030, paper_049). Systems/empirical papers put problem and architecture/measurement before results (paper_020-paper_026, paper_036-paper_064).

## 5. Claim strength
Claims are strong when scoped to a model, construction, or measurement, and hedged around deployment assumptions or tradeoffs. Evidence: paper_023, paper_030, paper_041, paper_048, paper_049, paper_056, paper_062-paper_064.

## 6. Contribution list
Medium confidence: many full PDFs expose a problem/model/mechanism/evidence sequence, but exact numbered/bulleted contribution-list formatting was not preserved in cards. Inspect PDFs for exact formatting.

## 7. Evaluation story
Formal papers evaluate by property/proof; storage and systems papers evaluate by baseline and failure mode; blockchain/DAO papers evaluate by metric, mechanism, or economic/security outcome. Evidence: paper_010-paper_013, paper_020-paper_026, paper_036-paper_064.

## 8. Limitation framing
Limitation and tradeoff framing is explicit when the paper centers impossibility, privacy limits, resource tradeoffs, TEE assumptions, incentive failures, or protocol overheads. Evidence: paper_023, paper_025, paper_030, paper_041, paper_048, paper_049, paper_057, paper_062-paper_064.

## Cross-dimensional notes
- Venue norms detected: security and crypto venues commonly impose problem/model/evaluation structure; do not treat that alone as individual style.
- Time-varying signals: early algebra/RFID/voting and storage work shifts into cloud integrity, TEEs, smart contracts, consensus fairness, DAO metrics, and AI/crypto harms.
- Insufficient-evidence flags: exact figure/table design, contribution-list typography, and related-work placement.
