# Cross-Paper Pattern Table

| Pattern | Papers supporting it | Counterexamples | Confidence | Notes |
|---|---|---|---|---|
| Starts from a concrete security, privacy, reliability, or economic assumption failure. | paper_001, paper_002, paper_004, paper_005, paper_006, paper_007, paper_008, paper_009, paper_020, paper_021, paper_022, paper_023, paper_024, paper_026, paper_029, paper_045, paper_058, paper_034, paper_036, paper_039, paper_041, paper_042, paper_046, paper_047, paper_048, paper_049, paper_050, paper_051, paper_052, paper_053, paper_054, paper_055, paper_056, paper_057, , paper_059, paper_061, paper_062, paper_063, paper_064, paper_014, paper_016, paper_017, paper_018, paper_019, paper_031, paper_035, paper_044,  | paper_010, paper_011, paper_013 | stable pattern | Full-PDF corpus strengthens the original assumption-failure pattern across storage, RFID, and blockchain. |
| Converts adversarial behavior into a model, primitive, property, game, or metric. | paper_001, paper_002, paper_003, paper_010, paper_011, paper_013, paper_015, paper_029, paper_030, paper_035, paper_043, paper_044, paper_025, paper_027, paper_046, paper_049, paper_052, paper_056, paper_062, paper_064, paper_034, paper_036, paper_039, paper_041, paper_042, , paper_047, paper_048, , paper_050, paper_051, , paper_053, paper_054, paper_055, , paper_057, paper_058, paper_059, paper_061, , paper_063,  | none | stable pattern | This remains the strongest cross-corpus signal. |
| Treats economics or strategic behavior as part of security when incentives are exposed. | paper_007, paper_008, paper_009, paper_025, paper_027, paper_046, paper_049, paper_052, paper_056, paper_062, paper_064, paper_034, paper_036, paper_041, , , paper_051, , paper_054, , paper_059, ,  | paper_010, paper_011, paper_013, paper_015 | stable pattern | Expanded from blockchain-only MEV to bug bounties, DAOs, consensus ordering, and collective investment algorithms. |
| Studies constrained environments where conventional cryptography alone is not enough. | paper_014, paper_016, paper_017, paper_018, paper_019, paper_031, paper_035, paper_044, , , , , paper_023, , paper_033, ,  | paper_010, paper_011 | stable pattern | Includes RFID, e-passports, computational RFIDs, noisy biometrics, password vaults, and cloud privacy limits. |
| Builds verifiable storage or data-availability mechanisms around auditability and failure locality. | paper_002, paper_020, paper_021, paper_022, paper_023, paper_024, paper_026, paper_029, paper_045, paper_058, ,  | paper_007, paper_034 | stable pattern | This revives a major storage-integrity line that was underrepresented in v2. |
| Uses trusted execution or attestable hardware as a bridge across trust boundaries, while preserving caveats. | paper_004, paper_006, paper_037, paper_038, paper_040, paper_047, paper_048, paper_050, paper_057, ,  | paper_003, paper_021 | stable pattern | Coauthor risk is high; apply mainly to TEE/oracle/delegation/order-flow contexts. |
| Moves from formal definitions to deployable systems when the domain demands both. | paper_004, paper_006, paper_021, paper_026, paper_033, paper_036, paper_038, paper_043, paper_047, paper_048, paper_050, paper_056, paper_057, paper_062 | paper_010, paper_011 | stable pattern | Full PDFs show the pattern across cloud storage, PRF services, trusted hardware, and consensus. |
| Frames fairness, privacy, decentralization, or order as measurable/composable properties rather than slogans. | paper_001, paper_032, paper_039, paper_049, paper_052, paper_056, paper_059, paper_062, paper_064 | paper_020, paper_022 | stable pattern | Strong in DAO, consensus, ML fairness, confidential ledgers, and collective investment work. |
| Presents papers through a problem/model/mechanism/evidence sequence. | paper_010, paper_011, paper_012, paper_013, paper_014, paper_015, paper_016, paper_017, paper_018, paper_019, paper_020, paper_021, paper_022, paper_023, paper_024, paper_025, paper_026, paper_027, paper_028, paper_029, paper_030, paper_031, paper_032, paper_033, paper_034, paper_035, paper_036, paper_037, paper_038, paper_039, paper_040, paper_041, paper_042, paper_043, paper_044, paper_045, paper_046, paper_047, paper_048, paper_049, paper_050, paper_051, paper_052, paper_053, paper_054, paper_055, paper_056, paper_057, paper_058, paper_059, paper_060, paper_061, paper_062, paper_063, paper_064, paper_001, paper_003, paper_005, paper_006, paper_007, paper_009 | none | stable pattern | Full PDFs make this a stronger writing-structure claim, though exact contribution-list formatting remains low-confidence. |
| Detailed figure/table and related-work placement remain paper-specific. | paper_010, paper_011, paper_012, paper_013, paper_014, paper_015, paper_016, paper_017, paper_018, paper_019, paper_020, paper_021, paper_022, paper_023, paper_024, paper_025, paper_026, paper_027, paper_028, paper_029, paper_030, paper_031, paper_032, paper_033, paper_034, paper_035, paper_036, paper_037, paper_038, paper_039, paper_040, paper_041, paper_042, paper_043, paper_044, paper_045, paper_046, paper_047, paper_048, paper_049, paper_050, paper_051, paper_052, paper_053, paper_054, paper_055, paper_056, paper_057, paper_058, paper_059, paper_060, paper_061, paper_062, paper_063, paper_064 | none | low-confidence inference | Cards did not preserve figure contents or full section text, so downstream users should inspect PDFs for precise layout imitation. |

## Stable patterns
- Assumption-failure framing now appears across 2000-2026 and across storage, RFID/e-passports, low-entropy secrets, ML/data systems, trusted hardware, and blockchain economics.
- Model/primitive/metric construction is stable across formal crypto papers, systems papers, and recent cryptoeconomic work.
- The corpus repeatedly decomposes problems into system role, adversary or strategic participant, construction or measurement, and explicit baseline.
- Full PDFs strengthen the presentation pattern: most papers use problem/model/mechanism/evidence order, but exact figure and related-work habits remain paper-specific.

## Area-specific patterns
- Formal cryptography and algebraic-protocol work: paper_010, paper_011, paper_013, paper_015, paper_029, paper_030, paper_035, paper_043, paper_044.
- RFID/e-passport/biometric/password/low-entropy security: paper_014, paper_016, paper_017, paper_018, paper_019, paper_031, paper_035, paper_044, , paper_033, .
- Cloud storage integrity and availability: paper_020, paper_021, paper_022, paper_023, paper_024, paper_026, paper_029, paper_045, paper_058.
- Trusted execution and attested systems: paper_037, paper_038, paper_040, paper_047, paper_048, paper_050, paper_057, , .
- Blockchain, DAO, consensus, and cryptoeconomic mechanisms: paper_034, paper_036, paper_039, paper_041, paper_042, paper_046, paper_047, paper_048, paper_049, paper_050, paper_051, paper_052, paper_053, paper_054, paper_055, paper_056, paper_057, paper_058, paper_059, paper_061, paper_062, paper_063, paper_064.
- ML/data-driven application security: paper_032, paper_060, paper_063.

## Time-varying patterns
- 2000-2006 papers emphasize algebraic protocol design, mixnets, RFID/e-passport security, and low-cost authentication.
- 2008-2014 papers expand into cloud storage integrity, FlipIt-style persistent compromise, and low-entropy/honey-encryption designs.
- 2015-2019 papers add ML/data-system security, trusted execution, secret sharing, and blockchain resource/incentive mechanisms.
- 2020-2026 papers concentrate on smart-contract economics, order fairness, DAO governance metrics, protected order flow, AI-agent/crypto harms, and collective investment tradeoffs.

## Coauthor attribution risks
- Nearly all systems and blockchain papers are heavily coauthored; coauthor and IC3/Cornell-area norms are a major attribution risk.
- Earlier formal papers are also often coauthored with Jakobsson, Kaliski, Ristenpart, Rivest, Oprea, and others; solo attribution should remain bounded.
- Full PDFs improve evidence anchors but do not eliminate authorship-risk for writing or methodology.

## Low-confidence inferences
- Exact figure/table conventions, contribution-list formatting, and related-work placement remain low-confidence because cards preserve only anchors, not full layout text.
- Claims about personal mentoring, lab culture, politics, emotional style, or private beliefs remain unsupported.
- The full downloaded set still omits many DBLP records with no accessible PDF candidate.
