# Evidence Map

## Evidence map
- Pattern: Starts from a concrete security, privacy, reliability, or economic assumption failure.
  - Supporting papers: paper_001 abstract, paper_002 abstract, paper_004 abstract, paper_005 abstract, paper_006 abstract, paper_007 abstract, paper_008 abstract, paper_009 abstract, paper_020, paper_021, paper_022, paper_023, paper_024, paper_026, paper_029, paper_045, paper_058, paper_034, paper_036, paper_039, paper_041, paper_042, paper_046, paper_047, paper_048, paper_049, paper_050, paper_051, paper_052, paper_053, paper_054, paper_055, paper_056, paper_057, , paper_059, paper_061, paper_062, paper_063, paper_064, paper_014, paper_016, paper_017, paper_018, paper_019, paper_031, paper_035, paper_044, .
  - Confidence: stable pattern.
- Pattern: Converts adversarial behavior into a model, primitive, property, game, or metric.
  - Supporting papers: paper_001 abstract, paper_002 abstract, paper_003 abstract, paper_010, paper_011, paper_013, paper_015, paper_029, paper_030, paper_035, paper_043, paper_044, paper_025, paper_027, paper_046, paper_049, paper_052, paper_056, paper_062, paper_064, paper_034, paper_036, paper_039, paper_041, paper_042, , paper_047, paper_048, , paper_050, paper_051, , paper_053, paper_054, paper_055, , paper_057, paper_058, paper_059, paper_061, , paper_063, .
  - Confidence: stable pattern.
- Pattern: Treats economics or strategic behavior as part of security when incentives are exposed.
  - Supporting papers: paper_007 abstract, paper_008 abstract, paper_009 abstract, paper_025, paper_027, paper_046, paper_049, paper_052, paper_056, paper_062, paper_064, paper_034, paper_036, paper_041, , , paper_051, , paper_054, , paper_059, , .
  - Confidence: stable pattern.
- Pattern: Studies constrained environments where conventional cryptography alone is not enough.
  - Supporting papers: paper_014, paper_016, paper_017, paper_018, paper_019, paper_031, paper_035, paper_044, , , , , paper_023, , paper_033, , .
  - Confidence: stable pattern.
- Pattern: Builds verifiable storage or data-availability mechanisms around auditability and failure locality.
  - Supporting papers: paper_002 abstract, paper_020, paper_021, paper_022, paper_023, paper_024, paper_026, paper_029, paper_045, paper_058, , .
  - Confidence: stable pattern.
- Pattern: Uses trusted execution or attestable hardware as a bridge across trust boundaries, while preserving caveats.
  - Supporting papers: paper_004 abstract, paper_006 abstract, paper_037, paper_038, paper_040, paper_047, paper_048, paper_050, paper_057, , .
  - Confidence: stable pattern.
- Pattern: Moves from formal definitions to deployable systems when the domain demands both.
  - Supporting papers: paper_004 abstract, paper_006 abstract, paper_021, paper_026, paper_033, paper_036, paper_038, paper_043, paper_047, paper_048, paper_050, paper_056, paper_057, paper_062.
  - Confidence: stable pattern.
- Pattern: Frames fairness, privacy, decentralization, or order as measurable/composable properties rather than slogans.
  - Supporting papers: paper_001 abstract, paper_032, paper_039, paper_049, paper_052, paper_056, paper_059, paper_062, paper_064.
  - Confidence: stable pattern.
- Pattern: Presents papers through a problem/model/mechanism/evidence sequence.
  - Supporting papers: paper_010, paper_011, paper_012, paper_013, paper_014, paper_015, paper_016, paper_017, paper_018, paper_019, paper_020, paper_021, paper_022, paper_023, paper_024, paper_025, paper_026, paper_027, paper_028, paper_029, paper_030, paper_031, paper_032, paper_033, paper_034, paper_035, paper_036, paper_037, paper_038, paper_039, paper_040, paper_041, paper_042, paper_043, paper_044, paper_045, paper_046, paper_047, paper_048, paper_049, paper_050, paper_051, paper_052, paper_053, paper_054, paper_055, paper_056, paper_057, paper_058, paper_059, paper_060, paper_061, paper_062, paper_063, paper_064, paper_001, paper_003, paper_005, paper_006, paper_007, paper_009.
  - Confidence: stable pattern.
- Pattern: Detailed figure/table and related-work placement remain paper-specific.
  - Supporting papers: all new cards mark that figure contents and full layout text are not stored.
  - Confidence: low-confidence inference.

### Merge log
- 2026-06-05: added 55 PDF-backed cards (paper_ids: paper_010, paper_011, paper_012, paper_013, paper_014, paper_015, paper_016, paper_017, paper_018, paper_019, paper_020, paper_021, paper_022, paper_023, paper_024, paper_025, paper_026, paper_027, paper_028, paper_029, paper_030, paper_031, paper_032, paper_033, paper_034, paper_035, paper_036, paper_037, paper_038, paper_039, paper_040, paper_041, paper_042, paper_043, paper_044, paper_045, paper_046, paper_047, paper_048, paper_049, paper_050, paper_051, paper_052, paper_053, paper_054, paper_055, paper_056, paper_057, paper_058, paper_059, paper_060, paper_061, paper_062, paper_063, paper_064). Patterns bumped: assumption-failure framing, constrained-environment security, cloud-storage integrity, TEE trust-boundary bridging, fairness/decentralization/order as measurable properties, and problem/model/mechanism/evidence writing sequence. Patterns demoted: none. New low-confidence patterns: exact figure/table and related-work placement remain paper-specific.
