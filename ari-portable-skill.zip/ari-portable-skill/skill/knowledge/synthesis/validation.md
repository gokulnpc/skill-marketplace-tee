# Held-Out Validation

## Verdict
PASS with medium confidence.

## Held-out set
- heldout_001: Liquefaction: Privately Liquefying Blockchain Assets (2025).
- heldout_002: Voting-Bloc Entropy: A New Metric for DAO Decentralization (2025).
- heldout_003: Resilient Alerting Protocols for Blockchains (2026).

## Regression check after PDF merge
- The new 55 synthesis cards strengthen rather than contradict the v2 held-out predictions.
- Liquefaction remains a good check for TEE-backed key-encumbrance and assumption-breaking.
- Voting-Bloc Entropy remains a good check for metric-building from a governance/decentralization gap.
- Resilient Alerting Protocols remains a good check for cryptoeconomic protocol framing and resource tradeoffs.

## Known-answer check 1: assumption failure
- Prediction from skill: a new paper should identify a foundational assumption in a deployed blockchain or security system and show how adversarial or strategic behavior breaks it.
- Held-out observation: Liquefaction starts from private-key ownership assumptions and uses TEE-backed key encumbrance to break them.
- Result: PASS.

## Known-answer check 2: model or metric construction
- Prediction from skill: a governance or incentive paper should turn an informal concept into a model, metric, or measurable object.
- Held-out observation: Voting-Bloc Entropy turns DAO decentralization into a metric and evaluates governance behavior.
- Result: PASS.

## Known-answer check 3: cryptoeconomic protocol framing
- Prediction from skill: a blockchain protocol paper should name the strategic failure mode, formalize rational/adversarial behavior, and expose resource tradeoffs.
- Held-out observation: Resilient Alerting Protocols names the alerting problem, models bribery against rational participants, and compares synchrony, trusted hardware, storage, and time tradeoffs.
- Result: PASS.

## Edge-case check
- Edge case: the held-out set is recent blockchain/DAO/cryptoeconomic work, so it validates the post-2020 direction better than the full career corpus.
- Result: PASS with caveat.

## Voice check
- The generated skill remains research-method advice, not personality imitation.
- Result: PASS.

## Copyright check
- The merge stores paper cards, metadata, and short anchors only. It does not store full PDFs, full abstracts, long excerpts, figure contents, or transcripts.
- Result: PASS.

## Required caveats for final skill
- Keep coauthor attribution risk visible.
- Keep exact figure/table and related-work imitation low-confidence unless the user asks for a paper-specific PDF pass.
- Do not generalize recent DAO/TEE/cryptoeconomic patterns to all of Ari Juels' work.
