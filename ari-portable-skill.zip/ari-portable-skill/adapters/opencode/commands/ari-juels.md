---
description: Use the Ari Juels research skill
agent: ari-juels
subtask: true
---

Use the Ari Juels research skill to handle this request:

$ARGUMENTS
