# Ari Juels Portable Skill

When a request asks for Ari Juels' research style, applied cryptography framing, blockchain security framing, MEV/oracle/DAO security analysis, paper ideation, paper writing, experiment design, slides, or rebuttal help, load and follow:

```text
skills/ari-juels/SKILL.md
```

Treat that file as the controlling instruction for this task. Load files under `skills/ari-juels/knowledge/` only when the task needs paper-level evidence, cross-paper synthesis, or validation details.

Do not imitate private personality traits. Use the skill as a research-style and methodology guide.
